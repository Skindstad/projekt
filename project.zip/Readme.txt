Gruppe projekt vedr. clientside programmering.
Gruppemedlemmer: Jakob Skindstad Frederiksen og Maria Clemmensen

Husk at installere node og derefter k�re:
> npm install mysql
> npm install mime

Programmet startes ved at k�de:
> node PageSelector.js
- og derefter bes�ge localhost:8001/

Nyttige adresser:
/query?select=SELECT%20sql%20statement
/query?query=INSERT20%INTO%20statement
/query?query=DELETE20%FROM%20statement
/query?query=UPDATE20%TABLE%20statement